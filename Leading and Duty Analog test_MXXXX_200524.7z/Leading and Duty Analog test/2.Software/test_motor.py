import pandas as pd
from tkinter import messagebox
import tkinter.ttk as ttk
import tkinter as tk
from tkinter.scrolledtext import ScrolledText
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
import matplotlib
import matplotlib.pyplot as plt
from instruments import *
from datetime import datetime as dt
import time

capture_start = False 

def draw_init(root, xy):
    ax = [] * 3
    plt.close()   
    plt.ion()   
    fig = Figure(figsize=(10,5), dpi=100)
    a = fig.add_subplot(311) 
    ax.append(a)
    a = fig.add_subplot(312, sharex = ax[-1]) 
    ax.append(a)
    a = fig.add_subplot(313) 
    ax.append(a)
    #add the canvas, which is what we intend to render the graph to. 
    canvas = FigureCanvasTkAgg(fig, root)
    canvas.draw()
    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=True)
    # add the toolbar, which is the traditional matplotlib tool bar.
    toolbar = NavigationToolbar2Tk(canvas, root)
    toolbar.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
    toolbar.update()   
    # plt.ion()   
    # fig, ax = plt.subplots()     
    # plt.title("RPM Monitor")
    # x, y = xy  
    # line, = ax.plot(x, y)           
    # plt.grid()
    # plt.draw()
    # return fig, ax, line
    for i in range(3):
        ax[i].grid()
        ax[i].relim()
    # ax[1].grid()
    return canvas, fig, ax
  
def plot_fg(plot_obj, x,y):  
    canvas, fig, ax = plot_obj
    clear_plot()
    for i in range(3):
        ax[i].plot(x[i], y[i])
        ax[i].grid()
        ax[i].relim()    
    root.update() 
    canvas.draw()
    root.update()     

def clear_plot():
    for i in range(3):
        ax[i].clear()
    canvas.draw()

# def get_scope_data(chlist):
#     # start new acquisition                    
#     scope.acquire('ON')
#     scope.set_trigger_continuous()
#     time.sleep(1)            
#     scope.set_trigger_single()
#     # get and plot waveform
#     ch_list = [1, 2]
#     scope.acquire_samples(ch_list)  
#     scope.acquire('ON')
#     scope.set_trigger_continuous()
    
# def check_fg_edge(scope, fg_thl, fg_thh, d_thl, d_thh):
#     #calculate leading angle
#     tout = Measurements.find_fg_rising_to_data_rising(scope.times, 
#             scope.waveform["CH1"], scope.waveform["CH2"], fg_thl, fg_thh, d_thl, d_thh, root= root)
#     if (tout[1] - tout[0]) <= 0.0001:
#         return True
#     else:
#         return False

# def test_delay_measurements():
#     """
#     示波器delay量測測試
#     """
#     scope.set_immediate_measurement_type('DEL')
#     str_send = "MEASUrement:IMMed:SOUrce1 CH1"
#     scope.write(str_send)    

#     x = [[], [], []]
#     y = [[], [], []]    
    
#     scope.timeout = 20000
#     times = []
#     print('[', end = '')
#     for i in range(1000):
#         delay = scope.query("MEASUrement:IMMed:VALue?")  
#         times.append(delay)
#         if i % 10 == 0:
#             print('.', end = '')
#     print(']')
    
#     x[0] = np.arange(len(times))
#     y[0] = np.asarray(times)
#     plot_fg((canvas, fig, ax),x,y)
        
def init_instruments():
    power, scope, multimeter, due_board = None, None, None, None
    #======== initial DAC and FG board
    due_board = DueBoard()
    due_board.auto_connect()
    if due_board.serial == None:
        sys.exit("Due Board not Found")
    else:
        print("Found Due Board") 

    due_board.load_dac_cal_data("./dud_dac_voltage.csv")       
    due_board.dac1_volt(2.5)    
    due_board.pwm(1000, 0)

    #========  Connect and initialize oscillscope
    device_dpo3034 = VisaInstruments.open_device('DPO3034')
    scope = TekScope(device_dpo3034) 
    if not scope.init():
        sys.exit("Scope init error!!")
    else:
        print("Tekttonix Oscillscope init OK!!") 
        scope.acquire('ON')
        scope.set_trigger_continuous()     

    #========  initial multimeter
    device_keithley2000 = VisaInstruments.open_device("MODEL 2000")
    if device_keithley2000 == None:
        sys.exit("Keithley 2000 init error!!")
    else:
        print("Keithley 2000 init OK!!")  
    multimeter = Keithlay2000(device_keithley2000)
    multimeter.init()
    multimeter.read_volt(sample_cnt = 100)     

    #======== set power supply 
    device = VisaInstruments.open_device(Keithlay2231A_30_3.name)
    if device != None:
        print("%s Found" % Keithlay2231A_30_3.name)
        power = Keithlay2231A_30_3(device)
        power.init()   
        power.set_output(0)            
        power.set_ch(1, 0, 0)
        power.set_ch(2, 0, 0)
        power.set_ch(3, 0, 0)
        power.disconnect()
    else:
        print("%s not Found" % Keithlay2231A_30_3.name)
        sys.exit("Power supply not Found")
        
    return power, scope, multimeter, due_board 

def test_capture_leading_angle_8320():
    global capture_start   
    if capture_start :
        return
    capture_start = True
    print("%s Start Capture" % dt.now())

    #generate control voltage list
    la_ctrl_voltage_lists = {"h2l":[], "l2h":[]}
    la_volt_start = 2.3
    la_volt_end = 4.7
    dv = 0.005                    
    la_ctrl_voltage_lists["l2h"].extend(list(np.arange(la_volt_start, la_volt_end, dv))) 
    
    la_volt_start = 2.7
    la_volt_end = 0.3
    dv = -0.005                    
    la_ctrl_voltage_lists["h2l"].extend(list(np.arange(la_volt_start, la_volt_end, dv)))     
                    
    for vm in [12]:
        for duty in [50, 100]:
            for la_ctrl_voltage_list in  la_ctrl_voltage_lists:
                if capture_start:
                    date = dt.now()
                    date_str = "%02d%02d%02d%02d%02d" % (date.year -2000, date.month, date.day, date.hour, date.minute)
                    fn = "./M8320_la_meas_%.1fV_d%d_%s_%s.csv" % (vm, duty, la_ctrl_voltage_list, date_str)                
                    msg = "VM = %.1fV duty = %.1f%% sweep type = %s\n" % (vm, duty, la_ctrl_voltage_list)
                    textbox["message"].insert(tk.END, msg)
                    textbox["message"].see(tk.END)
                    due_board.pwm(1000, duty)
                    capture_leading_angle_8320(vm, la_ctrl_voltage_lists[la_ctrl_voltage_list], fn) 
            
    capture_start = False    

def capture_leading_angle_8320(vm, ctrl_voltage_list, fn):
    """
    vm: power supply voltage
    """
    global capture_start
    # parameters
    fg_freq = 27   
    fg_thl, fg_thh, d_thl, d_thh = vm * 0.35, vm * 0.65, 1.5, 3
    
    due_board.dac1_volt(2.5) 
    time.sleep(1)
            
    #set record length
    length = 100000
    scope.timeout = 20000
    scope.set_persistence_off()
    scope.set_waveform_intensity(100)    
    scope.set_record_length(length)
    scope.set_read_length(start = 1, stop = length)   
    scope.set_acquire_mode("sample")  
    scope.set_trigger(1, 'RISE')
    scope.set_trigger_level(1, vm * 0.5)
    scope.set_seconds_per_division(0.02)       
    scope.set_horizontal_position(5)
    scope.set_volts_per_division(1, vm / 8)
    scope.set_volts_per_division(2, 1)
    scope.set_vertical_position(1, -4)
    scope.set_vertical_position(2, -4)

    while True:
        # set up power supply
        power.connect()
        power.set_ch(1, vm, 1)
        power.set_output(1)
        time.sleep(5)

        # Check FG frequency is normal
        measures = scope.get_measurement([1], 'FREQ') 
        if measures[0] < fg_freq * 1.1 and measures[0] > fg_freq * 0.8:  
            break
        else:
            power.set_output(0)
            time.sleep(1)
    
    # change scope resolution to fine
    length = 50000000
    scope.set_seconds_per_division(0.01)
    scope.set_record_length(length)
    scope.set_read_length(start = 1, stop = length) 
    scope.acquire('ON')
    scope.set_trigger_continuous()
    time.sleep(1)

    # get waveform
    scope.set_trigger_single()
    scope.acquire_samples([1, 2])  
    scope.set_trigger_continuous() 

    x = (scope.times, scope.times)
    y = (scope.waveform["CH1"], scope.waveform["CH2"]) 
    plot = Plot() 
    plot.init_plot(title = fn, row_num= 3, col_num= 1, sharex_no= 2, size = (8, 6))                   
    plot.plot_lines(x, y) 
                                  
    #check FG polarity after power on
    print("Check FG polarity")
    tout = Measurements.find_fg_rising_to_data_rising(scope.times, 
            scope.waveform["CH1"], scope.waveform["CH2"], 
            fg_thl, fg_thh, d_thl, d_thh, delay_time = 5e-3, root= root)
    
    if (tout[1] - tout[0]) <= 10e-3:
        scope.set_trigger_edge("RISE")
        fg_rising = True
        print("FG is rising edge")
    else:
        scope.set_trigger_edge("FALL")
        fg_rising = False
        print("FG is falling edge")
  
    
    
    tedges = {'t0':[], 't1':[], 't2':[]}
    vctrls = []
    fg_periods = []
    leading_angles = []    
    plot.init_sactter(title = fn, xlabel= 'voltage', ylabel= 'leading angle', size = (6, 6))
    for ctrl in ctrl_voltage_list:  
        if capture_start:                
            start_time = time.time() 
            #update control voltage    
            dac_cal = due_board.dac1_volt(ctrl) 
            time.sleep(2)
                                     
            # start new acquisition                       
            scope.set_trigger_single()
            scope.acquire_samples([1, 2])  
            scope.acquire('ON')
            scope.set_trigger_continuous() 
            
            # read vsp voltage
            voltage = multimeter.read_volt(sample_cnt = 100)                             
            
            # Calculate leading angle
            tout = Measurements.find_leading_angle_M8320(x[0], y[0], y[1], fg_thl, fg_thh, d_thl, d_thh, 
                                                         fg_polarity = fg_rising, root= root)
            # record control and duty data
            
            for n, t in enumerate(tout):
                key = 't%d' % n
                tedges[key].append(t)
                #print("%s = %.6f" % (key, t), end = ' ')            
            
            vctrls.append(voltage)    
            if len(tout) >= 3 :
                fg_periods.append(tout[1] - tout[0])
                leading_angles.append((fg_periods[-1]- (tout[2] - tout[1])) * 360 / fg_periods[-1])
            else:
                if len(tout) >= 2:
                    fg_periods.append(tout[1] - tout[0])
                else:
                    fg_periods.append(0)
                leading_angles.append(0)              

            # Plot
            x = (scope.times, scope.times, vctrls)
            y = (scope.waveform["CH1"], scope.waveform["CH2"], leading_angles)                
            plot.plot_lines(x, y)  
            plot.plot_scatter(vctrls, leading_angles) 
            
            time.sleep(0.1) 
            
            #print out result  
            msg = []                               
            msg.append("volt specified = %.3fV dac= %d actural = %.3fV " % (ctrl, dac_cal, voltage)) 
            msg.append("v = %.4f leading angle = %.2f \n" % 
                    (voltage,  leading_angles[-1]))
                                        
            for item in msg:
                textbox["message"].insert(tk.END, item)

            textbox["message"].see(tk.END)
            
            for item in msg:
                print(item)   
                
            print(dt.now(), end = " ")                         
            print("processing time = %.2f" % (time.time() - start_time))
            
            root.update()     

    df = pd.DataFrame(data={"Voltage": vctrls, "Leading_angle": leading_angles, "fg_period":fg_periods, 
                            't0': tedges['t0'], 't1': tedges['t1'],'t2': tedges['t2']})
    df.to_csv(fn , sep=',',index=False)  
    print("Save test to %s" % fn)  

    power.set_ch(1, 0, 0)
    power.set_output(0)
    power.disconnect()
    print("Power OFF")
 

def test_capture_duty():
    global capture_start   
    if capture_start :
        return
    capture_start = True
    print("%s Start Capture" % dt.now())

    vsp_ctrl_voltage_list = []
    vsp_volt_start = 0.5
    vsp_volt_end = 5
    dv = 0.5
        
    vsp_ctrl_voltage_list.extend(list(np.arange(vsp_volt_start, vsp_volt_end, dv))) 

    for vm in [8, 12]:
        if capture_start:
            date = dt.now()
            date_str = "%02d%02d%02d%02d%02d" % (date.year -2000, date.month, date.day, date.hour, date.minute)
            fn = "./M8320_duty_measurements_%.1fV_%s.csv" % (vm, date_str)
            capture_duty(vm, vsp_ctrl_voltage_list, fn) 
    capture_start = False    
   
def capture_duty(vm, vsp_ctrl_voltage_list, fn):
    """
    vm: power supply voltage
    """
    global capture_start    
    #set record length
    length = 1000000
    scope.timeout = 20000
    scope.set_record_length(length)
    scope.set_read_length(start = 1, stop = length)   
    scope.set_acquire_mode("sample")  
    scope.set_seconds_per_division(0.004) 
    scope.set_persistence_off()
    scope.set_waveform_intensity(100)
    scope.set_trigger(1, 'RISE')
    scope.set_horizontal_position(90)
                         
    due_board.dac1_volt(vsp_ctrl_voltage_list[0]) 
 
     # set up power supply
    power.connect()
    power.set_ch(1, vm, 1)
    power.set_output(1)
    time.sleep(5)

    vsps= []
    dutys = []
    fgs = []

    plot = Plot()     
    plot.init_plot(title = fn, row_num= 3, col_num= 1, sharex_no= 3, size = (10, 10)) 
    plot.init_sactter(title = fn, xlabel= 'voltage', ylabel= 'duty')                  
    
    for ctrl in vsp_ctrl_voltage_list:
        # parameters
        thl = vm * 0.8 
        thh = vm * 0.9 
        pwm_period = 33e-6
        fg_freq = 38
        
        if capture_start:                
            start_time = time.time() 
            #update control voltage    
            dac_cal = due_board.dac1_volt(ctrl) 
            time.sleep(0.5)
              
            # # check the FG frequency
            scope.set_seconds_per_division(0.02)
            scope.set_record_length(100000)
            scope.acquire('ON')
            scope.set_trigger_continuous()
            time.sleep(2)
            measures = scope.get_measurement([1], 'FREQ')      
            
            # read vsp voltage
            voltage = multimeter.read_volt(sample_cnt = 100)                   

            print("voltage = %.4f FG Frequency = %.2f" % (voltage, measures[0]))
            
            if measures[0] <= fg_freq * 0.8 or measures[0] >= fg_freq * 1.2:
                power.set_output(0) 
                time.sleep(1)
                power.set_output(1) 
                time.sleep(1)
            else:
                scope.set_record_length(length)
                scope.set_read_length(start = 1, stop = length / 2)                
                scope.set_seconds_per_division(0.00004) 
                time.sleep(1)
                # start new acquisition                       
                scope.set_trigger_single()
                # get waveform
                scope.acquire_samples([1, 2])  
                scope.acquire('ON')
                scope.set_trigger_continuous() 
                
                # read vsp voltage
                voltage = multimeter.read_volt(sample_cnt = 100)                             
                
                # Calculate Duty
                t_digital, digital , t_period, period_list, width_list, t_duty, duty_list = \
                    Measurements.find_transitions(scope.times, scope.waveform["CH2"], thl, thh, period = pwm_period, root = root)

                # record control and duty data
                if len(duty_list) > 0:
                    max_duty = max(duty_list)
                else:
                    #check if 0% 100% duty
                    if scope.waveform["CH2"][100] <= vm * 0.5:
                        max_duty = 0
                    else:
                        max_duty = 1

                # save test result
                vsps.append(voltage)                        
                dutys.append(max_duty)
                fgs.append(measures[0])

                # Plot
                x = (scope.times, t_digital, t_duty)
                y = (scope.waveform["CH2"], digital, duty_list)                
                plot.plot_lines(x, y)  
                plot.plot_scatter(vsps, dutys)    
                
                #print out result  
                msg = []                               
                msg.append("volt specified = %.3fV dac= %d actural = %.3fV " % (ctrl, dac_cal, voltage)) 
                msg.append("v = %.4f duty = %.4f \n" % 
                        (voltage, max_duty))
                                            
                for item in msg:
                    textbox["message"].insert(tk.END, item)

                textbox["message"].see(tk.END)
                
                for item in msg:
                    print(item)   
                    
                print(dt.now(), end = " ")                         
                print("processing time = %.2f" % (time.time() - start_time))
                
                root.update()     
    
    df = pd.DataFrame(data={"Voltage": vsps, "Duty": dutys, "FG":fgs})
    df.to_csv(fn , sep=',',index=False)  
    print("Save test to %s" % fn)  

    power.set_ch(1, 0, 0)
    power.set_output(0)
    power.disconnect()
          
def stop_capture():
    global capture_start
    capture_start = False
    print("\n%s Capture Stop\n" % dt.now())

def clear_text():
    textbox["message"].delete('1.0', tk.END)
#======================= GUI ===========================    
frms = {}
lbfrms = {}
btns = {}
entrys = {}
labels = {}
textbox = {}
root = tk.Tk()
root.title("GMT Motor Test")
notebook = ttk.Notebook(root)    
frms["uart"] = tk.Frame() 
frms["test"] = tk.Frame() 
frms["help"] = tk.Frame() 
notebook.add(frms["test"],text="Tests")  
notebook.add(frms["uart"],text="UART")   
notebook.add(frms["help"],text="HELP")   
notebook.grid(row = 0 , column = 0) 

#Test frames
lbfrms["buttons"] = tk.LabelFrame(frms["test"], text = "Commands")
lbfrms["status"] = tk.LabelFrame(frms["test"], text = "Status")
lbfrms["plot"] = tk.LabelFrame(frms["test"], text = "RPM")
lbfrms["buttons"].grid(row = 0 , column = 0, sticky = tk.W)
lbfrms["status"].grid(row = 1 , column = 0, sticky = tk.W)
lbfrms["plot"].grid(row = 2 , column = 0, sticky = tk.W)
#==== Buttons
btns['capture_la'] = tk.Button(lbfrms["buttons"],text="Capture LA",
    command=lambda: test_capture_leading_angle_8320()) 
btns['capture_duty'] = tk.Button(lbfrms["buttons"],text="Capture Duty",
    command=lambda: test_capture_duty()) 
btns['test_stop'] = tk.Button(lbfrms["buttons"],text="Stop",
    command=lambda: stop_capture()) 
btns['quit'] = tk.Button(lbfrms["buttons"],text="Quit",
    command=lambda: sys.exit("Exit Program"))     
btns['clear_plot'] = tk.Button(lbfrms["buttons"],text="Clear Plot",
    command=lambda: clear_plot()) 
btns['clear_text'] = tk.Button(lbfrms["buttons"],text="Clear Text",
    command=lambda: clear_text()) 

btns['capture_la'].grid(row = 0 , column = 0, sticky = tk.W + tk.E + tk.N + tk.S)
btns['capture_duty'].grid(row = 0 , column = 1, sticky = tk.W + tk.E + tk.N + tk.S)
btns['test_stop'].grid(row = 0 , column = 2, sticky = tk.W + tk.E + tk.N + tk.S)
btns['quit'].grid(row = 0 , column = 3, sticky = tk.W + tk.E + tk.N + tk.S)
btns['clear_plot'].grid(row = 1 , column = 0, sticky = tk.W + tk.E + tk.N + tk.S)
btns['clear_text'].grid(row = 1 , column = 1, sticky = tk.W + tk.E + tk.N + tk.S)
#==== Status
labels["pwm_duty"] = tk.Label(lbfrms["status"], fg = "blue", bg = "green", text = "0", font = "Helvetica 20 bold",
                             height = 1, width = 15, anchor = "e", relief = "raised")
labels["pwm_duty"].grid(row = 0 , column = 0, sticky = tk.W + tk.E + tk.N + tk.S)

textbox["message"] = ScrolledText(lbfrms["status"], width=150, height=15, font=("Consolas", 8), undo=True)     
textbox["message"].grid(row = 1 , column = 0,  sticky = tk.W )  
textbox["message"].config(bg='white', fg='blue') 
   
#==== Plot

# xy = ([],[])
# canvas, fig, ax = draw_init(lbfrms["plot"], xy)
VisaInstruments.list_devices()
power, scope, multimeter, due_board = init_instruments()  

root.mainloop() 