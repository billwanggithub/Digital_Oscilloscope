import pyvisa
import time
import numpy as np
from struct import unpack
import matplotlib.pyplot as plt
#import pyformulas as pf #https://stackoverflow.com/questions/28269157/plotting-in-a-non-blocking-way-with-matplotlib
import time
from datetime import datetime
import sys
from tqdm import tqdm
from tkinter import filedialog, messagebox, ttk
import os
import serial
import serial.tools.list_ports as srl
from scipy.interpolate import interp1d
import pandas as pd 
import pip

# class Plot:
#     @staticmethod
#     def init_interactive_plot():
#         fig = plt.figure()
#         canvas = np.zeros((480, 640))
#         screen = pf.screen(canvas, 'DPO3014') 
#         ax1 = fig.add_subplot(311) 
#         ax2 = fig.add_subplot(312, sharex = ax1)
#         ax3 = fig.add_subplot(313)
#         return screen, canvas, fig, ax1, ax2, ax3

#     @staticmethod
#     def interactive_plot(graph_obj, x, y):
#         screen, canvas, fig, ax1, ax2, ax3 = graph_obj
#         plt.clf()
#         ax1 = fig.add_subplot(311) 
#         ax2 = fig.add_subplot(312, sharex = ax1)
#         ax3 = fig.add_subplot(313,  sharex = ax1)        
#         #ax.autoscale_view(True, True, True)
#         ax1.grid()
#         #ax.relim()
#         ax1.plot(x[0], y[0])

#         ax2.relim()
#         #ax.autoscale_view(True, True, True)
#         ax2.grid()
#         #ax.relim()
#         ax2.plot(x[1], y[1])

#         ax3.relim()
#         #ax.autoscale_view(True, True, True)
#         ax3.grid()
#         #ax.relim()
#         ax3.plot(x[2], y[2])
                                    
#         fig.canvas.draw()
#         image = np.frombuffer(fig.canvas.tostring_rgb(), dtype=np.uint8)
#         image = image.reshape(fig.canvas.get_width_height()[::-1] + (3,))
#         screen.update(image)  
#         return image   

#     @staticmethod
#     def single_plot(x, y):
#         x[0], x[1], x[2] = x
#         y[0], y[1], y[2] = y
        
#         f, (ax1, ax2, ax3) = plt.subplots(3, 1, sharex=True) 
#         #ax1.autoscale_view(True, True, True)
#         ax1.grid()
#         ax1.relim()
#         ax2.grid()
#         ax2.relim()
#         ax3.grid()
#         ax3.relim()   
                        
#         ax1.plot(x[0], y[0])
#         ax2.plot(x[1], y[1])
#         ax3.plot(x[2], y[2])
#         plt.show()        
class Plot:
    def __init__(self):
        plt.ion()
    
    def init_plot(self, title = "plot", row_num = 1, col_num = 1, size = (8, 6), sharex_no = 1):
        """
        size unit is 80 pixel
        """        
        # check status by plt.rcParams['interactive'] or plt.isinteractive(), 
        self.row_num = row_num
        self.col_num = col_num
        self.ax_num = row_num * col_num
        self.lines_plot = []            
        self.fig_plot = plt.figure(num=None, figsize=size, dpi=80, facecolor='w', edgecolor='k')
        self.fig_plot.canvas.set_window_title(title) 
        self.axs_plot = [plt.axes()] * self.ax_num        
        for index in range(self.ax_num):
            if index < sharex_no and index > 0:
                self.axs_plot[index] = plt.subplot(self.row_num, self.col_num, index + 1, sharex = self.axs_plot[0])  
            else:
                self.axs_plot[index] = plt.subplot(self.row_num, self.col_num, index + 1)

            l1, = self.axs_plot[index].plot([], [])
            self.lines_plot.append(l1)
            self.axs_plot[index].grid()   
            self.axs_plot[index].relim()  
            self.axs_plot[index].autoscale_view()     
            
    def plot_lines(self, x, y):
        plot_num = len(x)
        for i in range(plot_num):
            self.lines_plot[i].set_data(x[i], y[i])
            self.axs_plot[i].relim()                   
            self.axs_plot[i].autoscale_view()
            plt.tight_layout()
            plt.draw()                
            plt.pause(1e-17)    

    def init_sactter(self, title = "scatter", xlabel = "x", ylabel = "y", size = (6, 4)):
        self.fig_scatt = plt.figure(num=None, figsize=size, dpi=80, facecolor='w', edgecolor='k')
        self.fig_scatt.canvas.set_window_title(title) 
        self.axs_scatt = plt.subplot(1,1, 1)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        self.lines_scatt = self.axs_scatt.scatter([], [])
        self.axs_scatt.grid()   
        self.axs_scatt.relim()  
        self.axs_scatt.autoscale_view()  

    def plot_scatter(self, x, y):
        #self.axs_scatt.scatter(x,y)
        self.lines_scatt.set_offsets(np.c_[x,y])
        xmin = min(x)
        xmax = max(x)
        ymin = min(y)
        ymax = max(y)
        
        if xmin < xmax:
            x_range = xmax-xmin
            self.axs_scatt.set_xlim(xmin - x_range * 0.1, xmax + x_range * 0.1)
        if ymin < ymax:          
            y_range = ymax-ymin
            self.axs_scatt.set_ylim(ymin - y_range * 0.1, ymax + y_range * 0.1)

        # self.axs_scatt.relim()                   
        self.axs_scatt.autoscale_view()
        plt.tight_layout()
        plt.draw()                
        plt.pause(1e-6)   

    def update(self):
        plt.tight_layout()
        plt.draw()                
        plt.pause(1e-6)           

class CSVFile:
    """
    https://www.shanelynn.ie/python-pandas-read_csv-load-data-from-csv-files/
    """
    @staticmethod
    def import_or_install(package):
        try:
            __import__(package)
        except ImportError:
            pip.main(['install', package])       
    
    @staticmethod
    def save_csv(fn, dict_data):
        df = pd.DataFrame(data = dict_data)
        try:
            df.to_csv(fn , sep=',',index=False)
        except:
            return False
        return True
    @staticmethod    
    def read_csv(fname):        
        df = pd.read_csv(fname, squeeze=True)
        return df

def test_csv_rw():
    dict_data = {}
    dict_data["x"] = [1 , 2, 3]
    dict_data["y"] = [14, 5, 6]
    fn = "test1.csv"
    CSVFile.save_csv("test1.csv", dict_data)
    fn =  filedialog.askopenfilename(initialdir='.', title="Select csv file to open", 
                                         filetypes = (("csvfiles","*.csv"),("all files","*.*")))    

    df_read = CSVFile.read_csv(fn)
    x, y = df_read.Voltage, df_read.Duty
    
    plt.scatter(x, y)
    plt.xlabel("x")
    plt.ylabel("y")
    plt.plot(x, y)
    plt.xlabel("x")
    plt.ylabel("y")
    
    plt.grid()
    print(df_read)
    plt.show()
     
class ISF:
    @staticmethod
    def read_isf(): 
        """
        Read and isf file
        peramble : preamble of isf file
        """
        fn =  filedialog.askopenfilename(initialdir='.', title="Select isf file to open", 
                                         filetypes = (("isffiles","*.isf"),("all files","*.*")))
        # reaf file as bytes to avoid encoding error
        with open(fn, 'rb') as f:
            data_raw = f.read()
        # ":CURVE " is the last tag of the header, followed by
        # '#XYYY..Y' with X being the number of bytes of YYY.
        # YYY..Y is the length of the datastream following in bytes. 
        token = ":CURVE #".encode()
        current_pos = data_raw.find(token,  0, 1024)
        # get preamble string
        preamble_string = data_raw[0:current_pos].decode()
        preamble = {}
        #read binary data
        leng = len(token)
        current_pos += leng 
        num = int(data_raw[current_pos:current_pos+1]) #read X
        current_pos +=1
        numofbytes = int(data_raw[current_pos: current_pos + num]) #read YYY
        # read data bytes
        current_pos += num
        end_pos = current_pos + numofbytes
        databytes = data_raw[current_pos:end_pos]
        print("len of data bytes = %d" % len(databytes))
        
        #decode preamble
        preamble["numofbits"] = int(preamble_string.split("BIT_NR ")[1].split(";")[0]) 
        preamble["numofbytes"] = int(preamble_string.split("BYT_NR ")[1].split(";")[0])   
        preamble["bin_format"] = preamble_string.split("BN_FMT ")[1].split(";")[0]
        preamble["byte_order"] = preamble_string.split("BYT_OR ")[1].split(";")[0]            
        preamble["xincr"] = float(preamble_string.split("XINCR ")[1].split(";")[0])
        preamble["xzero"] = float(preamble_string.split("XZERO ")[1].split(";")[0])
        preamble["ymult"] = float(preamble_string.split("YMULT ")[1].split(";")[0])
        preamble["yoff"] = float(preamble_string.split("YOFF ")[1].split(";")[0])
        preamble["yzero"] = float(preamble_string.split("YZERO ")[1].split(";")[0])
        preamble["points"] = int(preamble_string.split("NR_PT ")[1].split(";")[0])
        preamble["bits"] = int(preamble_string.split("BIT_NR ")[1].split(";")[0])
        preamble["ydiv"] = preamble_string.split("WFID ")[1].split(",")[2]
        preamble["xdiv"] = preamble_string.split("WFID ")[1].split(",")[3]                                                          

        # determine the datatype from header tags
        #RI:signed integer RP: positive integer FP:single-precision binary floating point
        #https://docs.scipy.org/doc/numpy/reference/generated/numpy.dtype.html#numpy.dtype
        datatype = ">" if preamble["byte_order"]  == "MSB" else "<"
        if preamble["bin_format"] == "RI": 
            datatype += "i"
        else:
            datatype += "u"

        # BYT_NR might be present with preceding header ":WFMPRE:BYT_NR"
        nobytes = preamble["numofbytes"]
        datatype += str(nobytes)
             
        # convert to integer    
        wave = np.frombuffer(databytes, datatype) #conver to interer
        volts = (wave - preamble['yoff']) * preamble['ymult'] + preamble['yzero']
        times = np.arange(0, preamble["xincr"] * len(volts), preamble["xincr"])
        
        return preamble, times, volts
           
class Measurements:
    # @staticmethod
    # def find_l2h_transition(tins, fgs, thl, thh):
    #     rising = False
    #     falling = False
    #     tout = []
        
    #     if fgs[0] >= (thl + thh) / 2:
    #         fg0 = 1
    #     else:
    #         fg0 = 0   

    #     for n, fg in enumerate(fgs):
    #         if n > 0:
    #             #get the previous fg value
    #             old = fgs[n-1]
    #             # find first rising edge 
    #             if old < thh and fg >= thh and fg > old:  
    #                 if rising == False:
    #                     t_l2h = tins[n] 
    #                     tout.append(t_l2h)   
    #                     rising = True
    #                     falling = False
    #             elif old > thl and fg <= thl and fg < old:
    #                 if falling == False:
    #                     t_h2l = tins[n] 
    #                     rising = False
    #                     falling = True
    #     return tout           

    @staticmethod
    def find_rising_edge(d_old, d_now, th):
        if d_old < th and d_now >= th and d_now > d_old:
            #print("\nR: %.2f %.2f %.2f" % (d_old, d_now, th))
            return True
        else:
            return False    
            
    @staticmethod
    def find_falling_edge(d_old, d_now, th):
        if d_old > th and d_now <= th and d_now < d_old:
            #print("\nF: %.2f %.2f %.2f" % (d_old, d_now, th))
            return True
        else:
            return False 
        
    @staticmethod
    def find_leading_angle_M8120(tins, fgs, dins, thl, thh, root = None):
        """
        FGH H2L -> FG H2L -> DATA L->H -> FG L2H
        """
        tout = []
        state = "FIND_1ST_FG_FALLING"
        print("[", end = '')
        for n, fg in enumerate(fgs):
            tnow = tins[n]
            fg_old = fgs[n-1]
            din_old = dins[n-1]
            din = dins[n]
            if n > 0:                
                if state == "FIND_1ST_FG_FALLING":
                    if Measurements.find_falling_edge(fg_old, fg, thl):
                        tout.append(tnow)
                        state = "FIND_1ST_FG_RISING"
                elif state == "FIND_1ST_FG_RISING":
                    if Measurements.find_rising_edge(fg_old, fg, thh):
                        if tnow - tout[-1] >= 0.001:
                            tout.append(tnow)
                            state = "FIND_2ND_FG_FALLING"                        
                elif state == "FIND_2ND_FG_FALLING":
                    if Measurements.find_falling_edge(fg_old, fg, thl):
                        if tnow - tout[-1] >= 0.001:
                            tout.append(tnow)
                            state = "FIND_1ST_DATA_RISING"
                elif state == "FIND_1ST_DATA_RISING":  
                    if Measurements.find_rising_edge(din_old, din, thh): 
                        if tnow - tout[-1] >= 0.001:
                            tout.append(tnow)                                    
                            state = "END"                                      
                else:
                    break
            told = tnow
            if (n % 100000) == 0:
                print('.', end = '')
                if root != None:
                    root.update()
        print("]")
        return tout           
   
    @staticmethod
    def find_fg_rising_to_data_rising(tins, fgs, dins, fg_thl, fg_thh, d_thl, d_thh, 
                                      delay_time = 4e-3, root = None):
        """
        For M8320 leading angle FG edge test
        delay_time: blanking time after FG edge for data rising edge 
        """
        tout = []
        state = "FIND_1ST_FG_RISING"
        print("[", end = '')
        for n, fg in enumerate(fgs):
            tnow = tins[n]
            fg_old = fgs[n-1]
            din_old = dins[n-1]
            din = dins[n]
            if n > 0:                
                if state == "FIND_1ST_FG_RISING":
                    if Measurements.find_rising_edge(fg_old, fg, fg_thh):
                        tout.append(tnow)
                        state = "FIND_1ST_DATA_RISING"                    
                elif state == "FIND_1ST_DATA_RISING": 
                    if Measurements.find_rising_edge(din_old, din, d_thh): 
                        if tnow - tout[0] >= delay_time:
                            tout.append(tnow)                                    
                            state = "END"                                                               
                else:
                    break
            told = tnow
            if (n % 100000) == 0:
                print('.', end = '')
                if root != None:
                    root.update()
        print("]")
        return tout    
               
    @staticmethod
    def find_leading_angle_M8320(tins, fgs, dins, fg_thl, fg_thh, d_thl, d_thh, fg_polarity = True, root = None):        
        """
        FG edge -> FG edge -> DATA edge -> FG edge
        """
        tout = []
        state = "FIND_1ST_FG_EDGE"
        print("[", end = '')
        for n, fg in enumerate(fgs):
            tnow = tins[n]
            fg_old = fgs[n-1]
            din_old = dins[n-1]
            din = dins[n]
            if n > 0:                
                if state == "FIND_1ST_FG_EDGE":
                    if fg_polarity :
                        edge_found = Measurements.find_rising_edge(fg_old, fg, fg_thh)
                    else:
                        edge_found = Measurements.find_falling_edge(fg_old, fg, fg_thl)
                    if edge_found:
                        tout.append(tnow)
                        state = "FIND_2ND_FG_EDGE"                           
                elif state == "FIND_2ND_FG_EDGE":
                    if fg_polarity :
                        edge_found = Measurements.find_falling_edge(fg_old, fg, fg_thl)
                    else:
                        edge_found = Measurements.find_rising_edge(fg_old, fg, fg_thh)
                    if edge_found:
                        state = "FIND_3RD_FG_EDGE"   
                elif state == "FIND_3RD_FG_EDGE":
                    if fg_polarity :
                        edge_found = Measurements.find_rising_edge(fg_old, fg, fg_thh)
                    else:
                        edge_found = Measurements.find_falling_edge(fg_old, fg, fg_thl)
                    if edge_found:
                        tout.append(tnow)
                        period = tout[1] - tout[0]                        
                        state = "FIND_1ST_DATA_EDGE"                                          
                elif state == "FIND_1ST_DATA_EDGE":  
                    if Measurements.find_rising_edge(din_old, din, d_thh): 
                        if tnow - tout[1] >= period * 3/4: #blanking time
                            tout.append(tnow)                                    
                            state = "END"                                                               
                else:
                    break
            told = tnow
            if (n % 100000) == 0:
                time.sleep(0.001)
                print('.', end = '')
                if root != None:
                    root.update()
        print("]")
        return tout           
                                                                                       
    @staticmethod
    def get_max_duty(periods, dutys, defalut_frequency = 60000):
        """
        exclude the dutys not at normal periods and get the maximum duty value
        """
        temp_dutys = []
        for n, period in enumerate(periods):
            if period <= 1.1 / defalut_frequency and period >= 0.9 / defalut_frequency:
                temp_dutys.append(dutys[n])
        return max(temp_dutys)       
    
    @staticmethod
    def find_transitions(tins, dins, thl, thh, period = 16.67e-6, clamp_period = False, root = None):
        """
        Find duty cycles and period
        return: transition times and digital data
        """
        max_period = period * 1.5
        dt = tins[1] - tins[0]        
        t_transition = [] # every data transition
        # digitized data
        t_digital = [] # every data transition with time expand for plot        
        digital = []
        #period and pulse width
        t_period = []
        period_list = []
        width_list = [] 
        # duty       
        t_duty = []
        duty_list = []
        state = "FIND_RISING_EDGE"
        print("[", end = '')
        for n, din in enumerate(dins):
            tnow = tins[n]
            din_old = dins[n-1]
            din = dins[n]
            if n > 0:                
                if state == "FIND_RISING_EDGE":
                    edge_found = Measurements.find_rising_edge(din_old, din, thh)
                    if edge_found:
                        t_transition.append(tnow)
                        # expand time for digital plot
                        t_digital.append(tnow - dt)
                        digital.append(0)  
                        t_digital.append(tnow)
                        digital.append(1)         
                                                             
                        if len(t_transition) >= 3:   
                            period =  t_transition[-1] - t_transition[-3]
                            width =  t_transition[-2] - t_transition[-3]                                                       
                            if len(period_list) > 0: 
                                t_period.append(t_transition[-3] - dt)                                                                     
                                period_list.append(period_list[-1])
                                width_list.append(width_list[-1])     
                            t_period.append(t_transition[-3]) 
                            if clamp_period:                        
                                if period >= max_period:                                                                                                                                                                                        
                                    period_list.append(max_period)
                                    width_list.append(max_period)
                                else:
                                    period_list.append(period)
                                    width_list.append(width)                                    
                            else:
                                period_list.append(period)
                                width_list.append(width)
                              
                            # if period too long, calculate 0 or 100% duty                         
                            if period  >= max_period and len(period_list) >= 2:  
                                t_duty.append(t_transition[-3]) # previous rising edge
                                t_duty.append(t_transition[-3] + period_list[-2]) #sudo rising edge
                                t_duty.append(t_transition[-1] + dt)
                                if width <= period_list[-2]: 
                                    duty_list.append(width / period_list[-2])
                                    duty_list.append(0)
                                    duty_list.append(0)
                                else:
                                    duty_list.append(1)
                                    duty_list.append(1)  
                                    duty_list.append(1)                                          
                            else:
                                duty_list.append(width / period)                            
                                t_duty.append(t_transition[-3])                                                                       
                        state = "FIND_FALLING_EDGE"  
                elif state == "FIND_FALLING_EDGE":
                    edge_found = Measurements.find_falling_edge(din_old, din, thl)
                    if edge_found:
                        t_transition.append(tnow)
                        # expand time for digital plot
                        t_digital.append(tnow - dt)
                        digital.append(1)  
                        t_digital.append(tnow)
                        digital.append(0)    
                        state = "FIND_RISING_EDGE"                                                                                                             
                else:
                    break
            told = tnow
            if (n % 100000) == 0:
                print('.', end = '')
                if root != None:
                    root.update()
        print("]")
        return t_digital, digital , t_period, period_list, width_list, t_duty, duty_list                 

    
    # @staticmethod
    # def find_dutys1(tins, dins, thl, thh, defalut_frequency = 60000):
    #     max_period = 2 / defalut_frequency
    #     th2l = 0
    #     old = 0
    #     periods = [0]
    #     widths = [0]
    #     dutys = [0]
    #     tout = [0]
    #     rising = False
    #     falling = False
    #     if dins[0] >= (thl + thh) / 2:
    #         d0 = 1
    #     else:
    #         d0 = 0
    #     for n, din in enumerate(dins):
    #         if n > 0:
    #             old = dins[n-1]
    #             if old < thh and din >= thh and din > old:
    #                 if rising == False:    
    #                     tout.append(tins[n])
    #                     if len(tout) <= 2:
    #                         periods.append(tins[n])
    #                         # if d0 == 1:
    #                         #     widths.append(tins[n])
    #                         #     dutys.append(1)
    #                         # else:
    #                         widths.append(0)
    #                         dutys.append(0)                            
    #                     else:
    #                         period = tout[-1] - tout[-2]
    #                         width = th2l - tout[-2]
    #                         periods.append(period)
    #                         #check if 0% or 100% duty
    #                         if  period >= max_period:
    #                             if width / period > 0.5:
    #                                 widths.append(period)
    #                             else:
    #                                 widths.append(0)
    #                         else:
    #                             widths.append(width)
    #                         dutys.append(widths[-1] / periods[-1])
    #                     rising = True 
    #                     falling = False      
    #             elif old > thl and din <= thl and din < old:
    #                 if falling == False:
    #                     th2l = tins[n]
    #                     falling = True   
    #                     rising = False               
    #     return tout, widths, periods, dutys
     
class VisaInstruments:
    def __init__(self):
        pass

    @staticmethod
    def list_devices():
        rm = pyvisa.ResourceManager()
        rm_list = rm.list_resources()
        print("Found Visa Devices:")        
        for device in rm_list:
            print("%s" % device, end =" ==> ")
            try:
                x = rm.open_resource(device)
                iden = x.query("*IDN?\n")  
                print(iden)
            except:
                print("Device Communication Error") 
        rm.close()         
            
    @staticmethod
    def open_device(name): 
        x = None
        rm = pyvisa.ResourceManager()
        rm_list = rm.list_resources()
        for device in rm_list:
            try:
                x = rm.open_resource(device)
                #time.sleep(2)
                # while True:
                #     data = x.query("*opc?")
                #     if data == '1\n':
                #         break
                #     time.sleep(0.1)    
                time.sleep(1)          
                iden = x.query("*IDN?\n")                 
                if name in iden:
                    #ps.write('SYSTem:REMote\n')
                    #print("Open Successful :" + iden)   
                    return x
            except:
                pass
        #print(name + " not found")
        return None 

class Uart:
    def __init__(self):
        pass
    
    @staticmethod
    def list_ports():         
        ports = list(srl.comports())
        message = "COM Port lists:\n"
        message += "=============================================================================\n"
        for p in ports:
            for x in p:
                message += x
                message += ' '
            message += '\n'
        message += "=============================================================================\n"            
        return ports, message
    
    @staticmethod
    def connect_port(port, baud = 9600, time_out = 5):  
        com = port.device   
        try:   
            #print("connect %s" % com)
            ser = serial.Serial(com, baud, timeout = time_out)
            #print("%s OK" % com)
        except:
            ser = None
        return ser 
    
    @staticmethod      
    def clear_serial(ser):
        ser.reset_input_buffer()
        ser.reset_output_buffer()    

    @staticmethod
    def send_command(ser,cmd, wait_time = 0.1):
        Uart.clear_serial(ser)
        strout = cmd+"\n"
        ser.write(strout.encode())
        time.sleep(wait_time)  

    @staticmethod
    def read_command(ser): 
        command = None       
        try:
            if ser.inWaiting():
                readbytes = ser.readline()
                #readbytes.replace(b'\r\n', b'\0')
                readstring = readbytes.decode()
                # parse the command string
                command = readstring.strip('\r\n').split(":")  
        except:
            command = None
        return command

class DueBoard:
    def __init__(self, board = "DUE"):
        self.boardname = board
        self.serial = None
        self.cal_dacs = []
        self.cal_voltages = []     
        
    def auto_connect(self):
        self.serial = None
        ports, message = Uart.list_ports()
        print(message)        
        for port in ports:
            ser = Uart.connect_port(port)
            if ser != None:
                time.sleep(3)
                Uart.send_command(ser, '*IDN?')
                cmds = Uart.read_command(ser)
                if cmds != None:
                    if cmds[0] == self.boardname:
                        self.serial = ser  

    def fg(self, freq, duty):
        cmd_str = "SET_HALLO:%d:%d" % (freq, duty)
        Uart.send_command(self.serial, cmd_str)        
    
    def pwm(self, freq, duty):
        """
        duty: 0~ 100
        """
        cmd_str = "SET_PWMO:%d:%d" % (freq, duty)
        Uart.send_command(self.serial, cmd_str) 
            
    def dac1(self, val, max_val = 4095):
        if val > max_val:
            val = max_val
        cmd_str = "SET_DACO:1:%d" % val
        Uart.send_command(self.serial, cmd_str)
        cmds = Uart.read_command(self.serial)
        if cmds != None:
            if cmds[0] != 'DAC1':
                print("Communication Error") 
                return False 
            else:
                return True   
        else:
            print("Communication Error") 
            return False 
        
    def dac1_volt(self, volt):
        if len(self.cal_dacs) == 0:
            self.load_dac_cal_data("./dud_dac_voltage.csv")
        vout = interp1d(np.asarray(self.cal_voltages), np.asarray(self.cal_dacs)) #, axis=1)
        dac_value = np.round(vout(volt))        
        self.dac1(dac_value)
        return dac_value

    def load_dac_cal_data(self, fn):
        data = pd.read_csv(fn) 
        self.cal_dacs = data['DAC'].to_list()
        self.cal_voltages = data['Voltage'].to_list()
     
class Keithlay2000:
    def __init__(self, meter, root = None):
        self.meter = meter
        self.number_of_readings = 100 
        self.interval_in_ms = 100 
        self.meter.timeout = 20000       
        
    def init(self):     
        initialization_cmds = ("*RST", # Clear registers
        "*CLS", # Clear Model 2000
        "INIT:CONT OFF" ,  # Init off
        "ABORT",
        "SENS:FUNC 'VOLT:DC'", #DCV
        "SYST:AZER:STAT ON" ,  # Auto zero on
        "SENS:VOLT:DC:AVER:STAT OFF" ,  # Filter off
        "SENS:VOLT:DC:NPLC 1" ,  # NPLC = 10
        "SENS:VOLT:DC:RANG 5" ,  # 10V range
        "SENS:VOLT:DC:DIG 7" ,  #   4 digits
        "FORM:ELEM READ" ,  #   Reading only
        "TRIG:COUN 1" ,  #  Trig count 1
        "SAMP:COUN %d" % self.number_of_readings ,  #Sample count 
        "TRIG:DEL 0" ,  # No trigger delay
        "TRIG:SOUR IMM" ,  # Immediate trigger 
        "DISP:ENAB ON",  # display" 
        )
        for c in initialization_cmds:
            self.meter.write(c)                    
        # self.meter.write("*rst; status:preset; *cls")     
        # self.meter.write("status:measurement:enable 512; *sre 1")
        # self.meter.write("sample:count %d" % self.number_of_readings)
        # self.meter.write("trigger:source bus")
        # self.meter.write("trigger:delay %f" % (self.interval_in_ms / 1000.0))        
    
    def read_volt(self, sample_cnt = 20):
        self.number_of_readings = sample_cnt
        cmd_str = "SAMP:COUN %d" % sample_cnt
        self.meter.write(cmd_str)  #Sample count         
        volts = self.meter.query_ascii_values('read?')
        return sum(volts) / len(volts)
    # def read_volts(self):
    #     self.meter.write("trace:points %d" % self.number_of_readings)
    #     self.meter.write("trace:feed sense1; feed:control next")          
    #     self.meter.write("initiate")        
    #     self.meter.write("*TRG")
    #     #time_start = time.time()     
    #     #voltages = self.meter.query("trace:data?")          
    #     voltages = self.meter.query_ascii_values("trace:data?")
    #     #print("time = %.2f" %( time.time() - time_start))
    #     #print("Average voltage: ", sum(voltages) / len(voltages))   
    #     self.meter.query("status:measurement?")
    #     self.meter.write("trace:clear; feed:control next")     
    #     return sum(voltages) / len(voltages)                

class FLuke45:
    def __init__(self, meter, root = None):
        self.meter = meter
        self.number_of_readings = 10 
        self.interval_in_ms = 100 
        self.meter.timeout = 20000       
        
    def init(self):     
        initialization_cmds = ("*rst", # reset
        "rems", # put the fluke into remote
        "vdc", # DC measurement
        "format 1", #data without unit 
        "range 5",  #
        "trigger 2", #set external trgger, without delay 
        )
        for c in initialization_cmds:
            self.meter.write(c)                    
        # self.meter.write("*rst; status:preset; *cls")     
        # self.meter.write("status:measurement:enable 512; *sre 1")
        # self.meter.write("sample:count %d" % self.number_of_readings)
        # self.meter.write("trigger:source bus")
        # self.meter.write("trigger:delay %f" % (self.interval_in_ms / 1000.0))        
    
    def read_volt(self):
        volts = []
        for i in range(self.number_of_readings):
            self.meter.write("*TRG")
            volt = self.meter.query('val?')
            volts.append(volt) 
        return sum(volts) / len(volts) 

class Keithlay2231A_30_3:
    name = '2231A-30-3' 
    
    def __init__(self, power, timeout = 20000):
        self.power = power 
        self.timeout = timeout
        
    def init(self):   
        self.power.timeout = self.timeout 
        initialization_cmds = ("SYST:REM", 
                               "*RST",
                               "*CLS"
        )
        for c in initialization_cmds:
            self.power.write(c) 
   
    def connect(self):
        self.power.write("SYST:REM")
    
    def disconnect(self):
       self.power.write("SYST:LOC")
       
    def select_channel(self, ch):
        self.power.write("INST:NSEL %d" % ch)
        
    def set_voltage(self, val):
        self.power.write("VOLT %f" % val)
        
    def set_current(self, val):
        self.power.write("CURR %f" % val)   
    
    def set_ch(self, ch, volt, ilim):
        self.select_channel(ch)
        self.set_voltage(volt)
        self.set_current(ilim)
           
    def set_output(self, state):
        self.power.write("OUTP %d" % state)                
   
class TekScope:
    """  
    VID: 0x0699
    0x0410 DPO3012
    0x0411 DPO3014
    0x0412 DPO3032
    0x0413 DPO3034
    0x0414 DPO3052
    0x0415 DPO3054
    0x0420 MSO3012
    0x0421 MSO3014
    0x0422 MSO3032
    0x0423 MSO3034
    0x0425 MSO3054
    """    
    def __init__(self, scope, root = None):
        self.binary_data = b'\0'
        self.preamble_string = ""
        self.preamble = {}
        self.record_length = 10000
        self.start = 1
        self.stop = 10000
        self.scope = scope
        self.waveform = {}
        self.waveform["duty"] = []
        self.times = [] 
        self.duty_decode = {}

    def init(self): 
        try:
            self.scope.write("dese 1")  # enable *opc in device event status enable register
            self.scope.write("*ese 1")  # enable *opc in event status enable register
            self.scope.write("*sre 0")  # no need to enable service requests
            self.scope.timeout = 20000
            return True
        except:
            return False
    
    def write(self, cmd):
        self.scope.write(cmd)
    
    def query(self, cmd):
        return self.scope.query(cmd)
    
    def auto_set(self):
        self.scope.write('AUTOSet') 
               
    def set_record_length(self, length):
        """ Set record memory deepth
        """
        self.record_length = length
        self.scope.write('HORIZONTAL:RECORDLENGTH %d' % length)
        
    def set_read_length(self, start = 1, stop= 10000):
        """ Set return waveform start and stop
        """
        self.start = start
        self.stop = stop
        self.scope.write('DATa:START %d' % start)
        self.scope.write('DATa:STOP %d'  % stop )        
 
    def read_opc(self):
        """ read operation complete bit from event status register
        """
        data = self.scope.query("*opc?")
        return data

    def read_preamble(self):
        """ Read Preamble
        """
        debug = False
        self.scope.write('header 1')     
        self.scope.write('verbose')  
        self.preamble_string = self.scope.query('wfmoutpre?') 
        self.scope.write('header 0')
        self.preamble["xincr"] = float(self.preamble_string.split("XINCR ")[1].split(";")[0])
        self.preamble["xzero"] = float(self.preamble_string.split("XZERO ")[1].split(";")[0])
        self.preamble["ymult"] = float(self.preamble_string.split("YMULT ")[1].split(";")[0])
        self.preamble["yoff"] = float(self.preamble_string.split("YOFF ")[1].split(";")[0])
        self.preamble["yzero"] = float(self.preamble_string.split("YZERO ")[1].split(";")[0])
        self.preamble["points"] = int(self.preamble_string.split("NR_PT ")[1].split(";")[0])
        self.preamble["bits"] = int(self.preamble_string.split("BIT_NR ")[1].split(";")[0])
        self.preamble["ydiv"] = self.preamble_string.split("WFID ")[1].split(",")[2]
        self.preamble["xdiv"] = self.preamble_string.split("WFID ")[1].split(",")[3]
        if debug:
            print("Scope Preamble:\n%s" % self.preamble)    

    def set_acquire_mode(self, mode):
        """ Sets the acquisition mode of the oscilloscope for all live waveforms
            {SAMple|PEAKdetect|HIRes|AVErage|ENVelope}
        """
        self.scope.write("acquire:mode " + mode)

    def acquire(self, start):
        """
        OFF/STOP stops acquisitions 
        ON/RUN starts acquisitions
        <NR1> = 0 stops acquisitions; any other value starts acquisitions.   
        """
        if start == 'ON':
            self.scope.write(':ACQ:STATE ON')
        elif start == 'OFF':
            self.scope.write(':ACQ:STATE OFF')
        else:
            print('Error format, ex: acquire(\'ON/OFF\')')
            
    def set_trigger_single(self):
        """ Single sequence acquisition
        """
        self.scope.write('ACQUIRE:STOPAFTER SEQuence')  
 
    def set_trigger_continuous(self):
        """ continually acquires acquisitions
        """
        self.scope.write('ACQUIRE:STOPAFTER RUNSTop')        
     
    def set_immediate_measurement_type(self, type):
        """ Set immediate measure type
        {AMPlitude|AREa|BURst|CARea|CMEan|CRMs|DELay|FALL|FREQuency
        |HIGH|LOW|MAXimum|MEAN|MINImum|NDUty|NEDGECount|NOVershoot
        |NPULSECount|NWIdth|PEDGECount|PDUty
        |PERIod|PHAse|PK2Pk|POVershoot|PPULSECount|PWIdth|RISe|RMS}
        """ 
        self.scope.write("measurement:immed:type " + type)

    def read_immediate_measurement_value(self, channel_list):
        """ read immediate measurement value
        """
        data = []
        for channel in channel_list:
            str_send = "MEASUrement:IMMed:SOUrce1 CH%d" % channel
            self.scope.write(str_send)
            self.scope.write('header 0')
            #str_ret = self.scope.query("MEASUrement:IMMed:type?")
            time.sleep(0.1)
            
            str_ret = self.scope.query("MEASUrement:IMMed:VALue?")
            data.append(float(str_ret.strip('\n')))
        return data

    def get_measurement(self, ch_list, type):
        """ measure type
        {AMPlitude|AREa|BURst|CARea|CMEan|CRMs|DELay|FALL|FREQuency
        |HIGH|LOW|MAXimum|MEAN|MINImum|NDUty|NEDGECount|NOVershoot
        |NPULSECount|NWIdth|PEDGECount|PDUty
        |PERIod|PHAse|PK2Pk|POVershoot|PPULSECount|PWIdth|RISe|RMS}
        """
        self.set_immediate_measurement_type(type)
        measurements = self.read_immediate_measurement_value(ch_list)
        return measurements
        # time_div = 4 / measurements[0] / 10
        # print("Set time division = %.3e s" % time_div)
        # scope.set_seconds_per_division(time_div)
        
    def set_seconds_per_division(self,seconds):
        self.scope.write("HORIZONTAL:SCALE " + str(seconds))

    def set_volts_per_division(self,channel,volts):
        self.scope.write("ch" + str(channel) + ":scale " + str(volts))    

    def set_vertical_position(self, channel, pos):
        """
        pos: 8 to -8 divisions, the position value for channel <x>, in divisions, from the center
        graticule. 
        """
        cmd = "CH%d:POSition %.2f" % (channel, pos)
        self.scope.write(cmd)
        
    def set_bandwidth_off(self, channel):
        self.scope.write("ch" + str(channel) + ":bandwidth off")

    def set_coupling_ac(self, channel):
        self.scope.write("ch" + str(channel) + ":coupling ac")

    def set_coupling_dc(self,channel):
        self.scope.write("ch" + str(channel) + ":coupling dc")

    def set_trigger(self, ch, edge):
        """
        ch : 1,2,3,4
        edge : 'RISE', 'FALL'
        """
        self.scope.write('TRIGGER:A:EDGE:SOURCE CH%d' % ch)
        self.scope.write('TRIGGER:A:EDGE:SLOPE %s' % edge)

    def set_trigger_edge(self, edge):
        """
        edge : 'RISE', 'FALL'
        """        
        self.scope.write('TRIGGER:A:EDGE:SLOPE %s' % edge)
    
    def set_trigger_level(self, ch, level):
        """
        ch : 1,2,3,4
        level : 
        """
        cmd = 'TRIGGER:A:LEVEL:CH%d %.3f' % (ch, level)
        self.scope.write(cmd)
       
    def set_persistence_off(self):        
        self.scope.write('DISplay:PERSistence -1')
        
    def set_waveform_intensity(self, intensity):  
        """
        intensity : 0~100%
        """      
        self.scope.write('DISPLAY:INTEnsITY:WAVEFORM %d' % intensity)

    def set_horizontal_position(self, pos):
        """
        pos : 0~ 100%
        """
        self.scope.write('HORizontal:DELay:MODe OFF')
        self.scope.write('HORizontal:POSition %d' % pos)
                   
    def acquire_samples(self, channel_list):
        """ Single sequence scope acquisition
        """
        debug = False       
        for channel in [1,2,3,4]:
            if channel in channel_list:
                self.scope.write("select:ch" + str(channel) + " on")            
            # else:
            #     self.scope.write("select:ch" + str(channel) + " off")            
            while self.read_opc() == '0\n':
                time.sleep(0.1)

        #self.scope.write("data:width 1;start %d;stop %d;encdg ascii" % (self.start, self.stop))
        # set start , stop and data type
        self.scope.write("data:width 1;start %d;stop %d;encdg rpb" % (self.start, self.stop))
           
        self.times = []      
        ch = 0         
        for channel in channel_list:
            ch_str = "CH%d" % channel
            #time_now = time.time()    
            self.scope.write("data:source ch" + str(channel))
            self.scope.write('header 0') 
            self.scope.write("curve?")

            databytes = self.scope.read_raw()

            headerlen =int(databytes[1]) - 48
            headerlen += 2
            header = databytes[:headerlen] 
            
            wave = databytes[headerlen:-1]
            wave = np.array(unpack('%sB' % len(wave),wave))
            
            self.read_preamble()
            volts = (wave - self.preamble['yoff']) * self.preamble['ymult'] + self.preamble['yzero']
            if ch == 0:
                self.times = np.arange(0, self.preamble["xincr"] * len(volts), self.preamble["xincr"])
            ch += 1                                         
            self.waveform[ch_str] = volts  
    
    def read_isf(self): 
        """
        Read and isf file
        peramble : preamble of isf file
        """
        fn =  filedialog.askopenfilename(initialdir='.', title="Select isf file to open", 
                                         filetypes = (("isffiles","*.isf"),("all files","*.*")))
        # reaf file as bytes to avoid encoding error
        with open(fn, 'rb') as f:
            data_raw = f.read()
        # ":CURVE " is the last tag of the header, followed by
        # '#XYYY..Y' with X being the number of bytes of YYY.
        # YYY..Y is the length of the datastream following in bytes. 
        token = ":CURVE #".encode()
        current_pos = data_raw.find(token,  0, 1024)
        # get preamble string
        self.preamble_string = data_raw[0:current_pos].decode()
     
        #read binary data
        leng = len(token)
        current_pos += leng 
        num = int(data_raw[current_pos:current_pos+1]) #read X
        current_pos +=1
        numofbytes = int(data_raw[current_pos: current_pos + num]) #read YYY
        # read data bytes
        current_pos += num
        end_pos = current_pos + numofbytes
        databytes = data_raw[current_pos:end_pos]
        print("len of data bytes = %d" % len(databytes))
        
        #decode preamble
        self.preamble["numofbits"] = int(self.preamble_string.split("BIT_NR ")[1].split(";")[0]) 
        self.preamble["numofbytes"] = int(self.preamble_string.split("BYT_NR ")[1].split(";")[0])   
        self.preamble["bin_format"] = self.preamble_string.split("BN_FMT ")[1].split(";")[0]
        self.preamble["byte_order"] = self.preamble_string.split("BYT_OR ")[1].split(";")[0]            
        self.preamble["xincr"] = float(self.preamble_string.split("XINCR ")[1].split(";")[0])
        self.preamble["xzero"] = float(self.preamble_string.split("XZERO ")[1].split(";")[0])
        self.preamble["ymult"] = float(self.preamble_string.split("YMULT ")[1].split(";")[0])
        self.preamble["yoff"] = float(self.preamble_string.split("YOFF ")[1].split(";")[0])
        self.preamble["yzero"] = float(self.preamble_string.split("YZERO ")[1].split(";")[0])
        self.preamble["points"] = int(self.preamble_string.split("NR_PT ")[1].split(";")[0])
        self.preamble["bits"] = int(self.preamble_string.split("BIT_NR ")[1].split(";")[0])
        self.preamble["ydiv"] = self.preamble_string.split("WFID ")[1].split(",")[2]
        self.preamble["xdiv"] = self.preamble_string.split("WFID ")[1].split(",")[3]                                                          

        # determine the datatype from header tags
        #RI:signed integer RP: positive integer FP:single-precision binary floating point
        #https://docs.scipy.org/doc/numpy/reference/generated/numpy.dtype.html#numpy.dtype
        datatype = ">" if self.preamble["byte_order"]  == "MSB" else "<"
        if self.preamble["bin_format"] == "RI": 
            datatype += "i"
        else:
            datatype += "u"

        # BYT_NR might be present with preceding header ":WFMPRE:BYT_NR"
        nobytes = self.preamble["numofbytes"]
        datatype += str(nobytes)
             
        # convert to integer    
        wave = np.frombuffer(databytes, datatype) #conver to interer
        volts = (wave - self.preamble['yoff']) * self.preamble['ymult'] + self.preamble['yzero']
        times = np.arange(0, self.preamble["xincr"] * len(volts), self.preamble["xincr"])
        self.times_isf = times
        self.volts_isf =  volts
        return times, volts
          
    def save_to_image(self):
    #https://forum.tek.com/viewtopic.php?f=580&t=138613&__cf_chl_jschl_tk__=e801dc1814202b984275940b46d2bb09adbbbe63-1588923646-0-ASt0V1KgSkG76nUXEK5PEF8Q455GHBMGLKbM8rjEy0ibMh73xygF8JxxU4aiT4b5XsOHBgXJO-54wmbb8WtdIVoCLtaWmibRGqpEl9WbwgIl39n_TRMeA_K_qLq6e5N4s5lPrWFRqdMFCPUGprzvrWr5Z9ltb2YyTscS78uAxTlVrD3EHXvWNVK8JuDoQgqCy7r4H5BVKfCqG-VgIq8oHcy0dv16duLLdirMBkqlJRF8-pHllsF1-LhIHmG-sdXLMWpny9FzROEX382ohrsNfF8KOkOsOpoFibnej8PCvqaQr6w7aqcmHYiYs88JfjYcAoZRSeEkhIapJ2lp6xX1Cy-_3xgFylbuiMJEpNeoBGd3M1d-28WJfunZfdRG9BgmdQ        
        fileSaveLocation = r'D:\Temp\\'
        self.scope.write("SAVe:IMAGe:FILEFormat PNG")
        self.scope.write("SAVe:IMAGe:INKSaver OFF")
        self.scope.write("HARDCopy STARt")
        imgData = self.scope.read_raw()

        # Generate a filename based on the current Date & Time
        dt = datetime.now()
        fileName = dt.strftime("%Y%m%d_%H%M%S.png")

        imgFile = open(fileSaveLocation + fileName, "wb")
        imgFile.write(imgData)
        imgFile.close()

    def decode_duty(self, tin, din, thresholds) :
        timein, datain = tin, din
        sample_time = timein[1] - timein[0]
        tdig = []
        ddig = []
        tduty = []
        dduty = []
        dperiod = []
        
        thdl = thresholds[0]
        thdh = thresholds[1]
        threshold = (thdl + thdh) / 2
        data_cnt = 0 # input list number
        data01 = 0 #digital data
        data01_old = 0 # old value of digital data
        period = 0.0
        duty = 0.0  
        period_old = 0
        duty_old = 0  
        time_now = 0    
        time01 = 0.0 #time @ 0 --> 1
        time10 = 0.0 #time @ 1 --> 0  
        cnt_01= 0 #number of transition from low to high
        val_old = 0
        

        #for val in  tqdm(datain) :            
        for val in  datain :         
            time_now = timein[data_cnt] 
            #deal first sample
            if data_cnt == 0 : 
                if val >= threshold:
                    data01 = 1
                else:
                    data01 = 0
            else:
                # set hsystersis 
                # at rising, must greater then thdh
                if val > val_old: 
                    if val >= thdh:
                        data01 = 1
                        # save at rising/falling edge
                        tdig.append(time_now - (sample_time * 0.001))
                        ddig.append(data01_old)                                      
                        tdig.append(time_now)
                        ddig.append(data01)                     
                # at falling, must less then thdl
                elif val < val_old:
                    if val <= thdl:
                        data01 = 0  
                        #save at rising/falling edge
                        tdig.append(time_now -(sample_time * 0.001))
                        ddig.append(data01_old)                                      
                        tdig.append(time_now)
                        ddig.append(data01)                           
                        
                # 0 -> 1, calculate period value
                if data01 > data01_old:                            
                    #if first transition detected, set first number of duty =0
                    if cnt_01== 0 : 
                        time01 = time_now
                        time10 = time_now
                        tduty.append(timein[0])
                        dduty.append(0)
                        dperiod.append(0)
                        duty = 0                                                                    
                    else :
                        period = time_now - time01
                        duty = (time10 - time01) / period   
                        #if period < period_max: 
                            #save old duty before dt    
                        tduty.append(time01 - sample_time)
                        dduty.append(duty_old)
                        dperiod.append(period_old) 
                        #save new value                                                       
                        tduty.append(time01)
                        dduty.append(duty)
                        dperiod.append(period)               
                        #update time01 and time10     
                        time01 = time_now 
                        time10 = time_now
                        period_old = period
                        duty_old = duty
                    cnt_01+= 1
                # 1 -> 0, latch the time from high to low
                elif data01 < data01_old :
                    time10 = time_now                                

            data01_old = data01   
            val_old = val                        
            data_cnt += 1
                      
        #save last duty
        tduty.append(time01 - sample_time)
        dduty.append(duty)    
        dperiod.append(period)
        tduty.append(time_now)
        dduty.append(duty) 
        dperiod.append(period)
        
        self.duty_decode["t_duty"] = tduty
        self.duty_decode["duty"] = dduty
        self.duty_decode["period"] = dperiod
        self.duty_decode["t_digital"] = tdig
        self.duty_decode["digital"] = ddig

def test_multimeter():
    # VisaInstruments.list_devices()  
    device = VisaInstruments.open_device("DUE")
    if device != None:
        print("DUE Found")       
    else:
        print("Due Not Found")      
    #  FLUKE 45
    device = VisaInstruments.open_device("FLUKE, 45")
    if device != None:
        print("FLUKE 45 Found")       
    else:
        print("FLUKE 45 Not Found")  
    
    # Keithley 2000    
    device = VisaInstruments.open_device("MODEL 2000")
    if device != None:
        print("Keithley 2000 Found")
        multimeter = Keithlay2000(device)
        multimeter.init()
        n = 0
        while True:
            n += 1
            volt = multimeter.read_volt() 
            print("No = %d Average Voltage = %.6f" % (n, volt))            
    else:
        print("Keithley 2000 Not Found")     

def test_keithley_2231A():    
    # Keithley 2231A   
    name = Keithlay2231A_30_3.name
    device = VisaInstruments.open_device(name)
    if device != None:
        print("%s Found" % name)
        power = Keithlay2231A_30_3(device)
        power.init()       
        power.select_channel(1)    
        power.set_voltage(12)
        power.set_current(1)
        power.select_channel(2)    
        power.set_voltage(0)
        power.set_current(0) 
        power.select_channel(3)    
        power.set_voltage(0)
        power.set_current(0)                
        power.set_output(1)  
    else:
        print("%s not Found" % name)
    power.disconnect()
                    
def test_fluke():
    ports, message = Uart.list_ports()
    print(message)        
    for port in ports:
        ser = Uart.connect_port(port)
        time.sleep(3)
        Uart.send_command(ser, '*IDN?')
        cmds = Uart.read_command(ser)    

def test_dueboard_dac(volts):   
    due_board = DueBoard()
    due_board.auto_connect()
    if due_board.serial == None:
        sys.exit("Due Board not Found")
    else:
        print("Found Due Board")    
    
    #test FG output
    due_board.fg(100, 50)
    #due_board.load_dac_cal_data("./dud_dac_voltage.csv")
        
    #test DAC1 output
    while True:
        for volt in volts:
            dac_val = due_board.dac1_volt(volt)  
            print("dac = %d voltage = %.3f" % (dac_val, volt))      
            time.sleep(5)

def calibration_dac():
    #open DAC
    due_board = DueBoard()
    due_board.auto_connect()
    if due_board.serial == None:
        sys.exit("Due Board not Found")
    else:
        print("Found Due Board")  
    
    # open multimeter    
    device = VisaInstruments.open_device("MODEL 2000")
    multimeter = Keithlay2000(device)
    multimeter.init()   
    
    dacs = [0]
    voltages = [0]
    for i in range(0, 4106, 8):  
        start_time = time.time() 
        dac = i
        if dac >= 4095:
            dac = 4095
        due_board.dac1(dac)        
        time.sleep(2)             
        voltage = multimeter.read_volt()
        dacs.append(dac)
        voltages.append(voltage)
        print("time = %.3f DAC = %d Voltage = %.3f" % (time.time()- start_time, dac, voltage))
    voltages.append(5)
    dacs.append(4095)
       
    import pandas as pd
    df = pd.DataFrame(data={"DAC": dacs, "Voltage": voltages})
    df.to_csv("./dud_dac_voltage.csv", sep=',',index=False)  
    print("save data to dud_dac_voltage.csv")

def test_decode_duty():    
    preamble, times, volts = ISF.read_isf()
    t_digital, digital , t_period, period_list, width_list, t_duty, duty_list = \
        Measurements.find_transitions(times, volts, 2, 3, period = 40e-6)
 
    x = (times, t_digital, t_period, t_duty)
    y = (volts, digital, period_list, duty_list)
    
    plot = Plot()    
    plot.init_plot(row_num= 4, col_num= 1, sharex_no= 4)
    plot.plot_lines(x, y)
    input("Press Any Key")

def test_interactive_plot():
        plot = Plot()    
        plot.init_plot(title = "line", row_num= 2, col_num= 1, sharex_no= 2)
        plot.init_sactter(title = "scatter", xlabel= "tx", ylabel='ty')
        
        x = [[], []]
        y = [[], []]
        
        i = 0
        while True:
            x[0].append(i)
            x[1].append(i)
            y[0].append(i * i)
            y[1].append(i * i * i)
            plot.plot_lines(x, y)
            plot.plot_scatter(x[0], y[0])
            i += 1    
   
if __name__ == "__main__":
    #test_csv_rw()
    test_interactive_plot()
    #test_decode_duty()
    #test_keithley_2231A()
    #test_fluke()
    #test_dueboard_dac([0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7])
    #test_multimeter()
    #calibration_dac()
 
