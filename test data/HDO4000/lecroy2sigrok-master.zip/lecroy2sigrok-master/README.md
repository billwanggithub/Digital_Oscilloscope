# lecroy2sigrok
Convert a Lecory waveform to be imported in sigrok
